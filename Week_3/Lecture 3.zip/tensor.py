import math


def _broadcast_shape(a, b):
    """Return output shape after broadcasting, or raise if incompatible."""
    if len(a.shape) != len(b.shape):
        raise ValueError(f"rank mismatch: {a.shape} vs {b.shape}")
    out = []
    for x, y in zip(a.shape, b.shape):
        if x == y or x == 1 or y == 1:
            out.append(max(x, y))
        else:
            raise ValueError(f"shapes {a.shape} and {b.shape} are not broadcastable")
    return tuple(out)


class Tensor:
    """Flat list + shape + dtype. That's a tensor."""

    def __init__(self, data, shape, dtype=float):
        assert len(data) == math.prod(shape), "data length must equal product of shape"
        self.data = [dtype(x) for x in data]  # flat, contiguous storage
        self.shape = tuple(shape)
        self.dtype = dtype

    def __repr__(self):
        return (
            f"Tensor(shape={self.shape}, dtype={self.dtype.__name__}, data={self.data})"
        )

    # --- elementwise ---
    def __add__(self, other):
        out_shape = _broadcast_shape(self, other)
        return Tensor(
            [
                a + b
                for a, b in zip(
                    self.expand(out_shape).data, other.expand(out_shape).data
                )
            ],
            out_shape,
            self.dtype,
        )

    def __sub__(self, other):
        neg = Tensor([-v for v in other.data], other.shape, other.dtype)
        return self + neg

    def __mul__(self, other):
        out_shape = _broadcast_shape(self, other)
        return Tensor(
            [
                a * b
                for a, b in zip(
                    self.expand(out_shape).data, other.expand(out_shape).data
                )
            ],
            out_shape,
            self.dtype,
        )

    # --- reduce ---
    def sum(self):
        return Tensor([sum(self.data)], shape=(1,), dtype=self.dtype)

    def max(self):
        return Tensor([max(self.data)], shape=(1,), dtype=self.dtype)

    # --- movement ---
    def reshape(self, new_shape):
        assert math.prod(new_shape) == math.prod(self.shape)
        return Tensor(self.data, new_shape, self.dtype)  # same list, new shape

    def expand(self, new_shape):
        assert len(new_shape) == len(self.shape)
        out = [0.0] * math.prod(new_shape)
        for idx in range(math.prod(new_shape)):
            src, stride = 0, 1
            tmp = idx
            for dim in reversed(range(len(new_shape))):
                coord = tmp % new_shape[dim]
                tmp //= new_shape[dim]
                src += (coord % self.shape[dim]) * stride
                stride *= self.shape[dim]
            out[idx] = self.data[src]
        return Tensor(out, new_shape, self.dtype)

    # --- linear algebra ---
    def __matmul__(self, other):
        M, K = self.shape
        K2, N = other.shape
        assert K == K2, f"inner dims must match: {K} vs {K2}"
        out = []
        for i in range(M):
            for j in range(N):
                val = sum(
                    self.data[i * K + k] * other.data[k * N + j] for k in range(K)
                )
                out.append(val)
        return Tensor(out, shape=(M, N), dtype=self.dtype)
